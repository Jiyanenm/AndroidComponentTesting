package com.example.loginapp

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.loginapp.viewmodel.LoginViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.*
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class LoginViewModelTest {

    @get:Rule
    val instantExecutorRule = InstantTaskExecutorRule()

    private val testDispatcher = StandardTestDispatcher()

    @Test
    fun login_success_resetsFailureCount() = runTest {
        val vm = LoginViewModel()
        vm.onEmailChange("test@example.com")
        vm.onPasswordChange("password123")
        vm.login()
        advanceUntilIdle()
        assertEquals(0, vm.uiState.value.failureCount)
        assertEquals(true, vm.uiState.value.navigateToMain)
    }

    @Test
    fun login_failure_incrementsFailureCount_andLockout() = runTest {
        val vm = LoginViewModel()
        vm.onEmailChange("test@example.com")
        vm.onPasswordChange("wrongpass")
        repeat(3) { vm.login(); advanceUntilIdle() }
        assertEquals(3, vm.uiState.value.failureCount)
        assertEquals(true, vm.uiState.value.isLocked)
    }
}
