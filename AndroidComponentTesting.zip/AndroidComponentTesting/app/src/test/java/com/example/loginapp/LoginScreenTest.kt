package com.example.loginapp

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import com.example.loginapp.ui.LoginScreen
import com.example.loginapp.viewmodel.LoginViewModel
import org.junit.Rule
import org.junit.Test

class LoginScreenTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<ComponentActivity>()

    private fun setContent(viewModel: LoginViewModel = LoginViewModel()) {
        composeRule.setContent { LoginScreen(viewModel) }
    }

    @Test
    fun loginButton_disabled_whenInputsInvalid() {
        setContent()

        composeRule.onNodeWithText("Login")
            .assertIsNotEnabled()

        composeRule.onNodeWithText("Email")
            .performTextInput("invalid-email")

        composeRule.onNodeWithText("Password")
            .performTextInput("short")

        composeRule.onNodeWithText("Login")
            .assertIsNotEnabled()
    }

    @Test
    fun loginButton_enabled_whenInputsValid() {
        setContent()

        composeRule.onNodeWithText("Email").performTextInput("test@example.com")
        composeRule.onNodeWithText("Password").performTextInput("password123")

        composeRule.onNodeWithText("Login")
            .assertIsEnabled()
    }

    @Test
    fun loginFailure_showsError_andIncrementsFailureCount() {
        setContent()

        // Valid fields
        composeRule.onNodeWithText("Email").performTextInput("test@example.com")
        composeRule.onNodeWithText("Password").performTextInput("wrongpass")

        composeRule.onNodeWithText("Login").performClick()

        composeRule.waitForIdle()

        composeRule.onNodeWithText("Invalid credentials")
            .assertIsDisplayed()
    }

    @Test
    fun lockout_afterThreeFailures() {
        val vm = LoginViewModel()
        setContent(vm)

        composeRule.onNodeWithText("Email").performTextInput("test@example.com")
        composeRule.onNodeWithText("Password").performTextInput("wrongpass")

        repeat(3) {
            composeRule.onNodeWithText("Login").performClick()
            composeRule.waitForIdle()
        }

        composeRule.onNodeWithText("Account locked after 3 failures")
            .assertIsDisplayed()

        composeRule.onNodeWithText("Login")
            .assertIsNotEnabled()
    }

    @Test
    fun offlineMode_showsOfflineMessage_andBlocksLogin() {
        val vm = LoginViewModel()
        vm.setOffline(true)
        setContent(vm)

        composeRule.onNodeWithText("Email").performTextInput("test@example.com")
        composeRule.onNodeWithText("Password").performTextInput("password123")

        composeRule.onNodeWithText("Login").performClick()

        composeRule.onNodeWithText("Offline: check your connection")
            .assertIsDisplayed()
    }

    @Test
    fun rememberMe_savesTokenAfterSuccess() {
        val vm = LoginViewModel()
        setContent(vm)

        composeRule.onNodeWithText("Email").performTextInput("test@example.com")
        composeRule.onNodeWithText("Password").performTextInput("password123")

        // enable remember me
        composeRule.onNodeWithText("Remember Me").performClick()

        composeRule.onNodeWithText("Login").performClick()
        composeRule.waitForIdle()

        assert(vm.uiState.value.navigateToMain)
        assert(vm.uiState.value.rememberMe)

        assert(vm.authRepository.getToken() != null)
    }

    @Test
    fun successfulLogin_triggersNavigation() {
        val vm = LoginViewModel()
        setContent(vm)

        composeRule.onNodeWithText("Email").performTextInput("test@example.com")
        composeRule.onNodeWithText("Password").performTextInput("password123")

        composeRule.onNodeWithText("Login").performClick()
        composeRule.waitForIdle()

        assert(vm.uiState.value.navigateToMain)
    }
}
