package com.example.loginapp

import androidx.arch.core.executor.testing.InstantTaskExecutorRule
import com.example.loginapp.viewmodel.LoginViewModel
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.runTest
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

class LoginViewModelTest {

    @get:Rule
    val instant = InstantTaskExecutorRule()

    @Test
    fun successfulLogin_navigatesAndResetsFailures() = runTest {
        val vm = LoginViewModel()

        vm.onEmailChange("test@example.com")
        vm.onPasswordChange("password123")
        vm.login()

        assertTrue(vm.uiState.value.navigateToMain)
        assertEquals(0, vm.uiState.value.failureCount)
    }

    @Test
    fun lockoutAfterThreeFailures() = runTest {
        val vm = LoginViewModel()

        repeat(3) {
            vm.onEmailChange("test@example.com")
            vm.onPasswordChange("wrongpass")
            vm.login()
        }

        assertTrue(vm.uiState.value.isLocked)
    }
}
