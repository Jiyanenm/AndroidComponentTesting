package com.example.loginapp.model

data class LoginUiState(
    val email: String = "",
    val password: String = "",
    val isLoading: Boolean = false,
    val error: String? = null,
    val isButtonEnabled: Boolean = false,
    val failureCount: Int = 0,
    val isLocked: Boolean = false,
    val isOffline: Boolean = false,
    val rememberMe: Boolean = false,
    val navigateToMain: Boolean = false
)
