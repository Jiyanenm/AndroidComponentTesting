package com.example.loginapp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.loginapp.model.LoginUiState
import com.example.loginapp.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class LoginViewModel(
    private val authRepository: AuthRepository = AuthRepository()
) : ViewModel() {

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState

    fun onEmailChange(email: String) {
        _uiState.value = _uiState.value.copy(email = email)
        validateInputs()
    }

    fun onPasswordChange(password: String) {
        _uiState.value = _uiState.value.copy(password = password)
        validateInputs()
    }

    fun onRememberMeChange(checked: Boolean) {
        _uiState.value = _uiState.value.copy(rememberMe = checked)
    }

    private fun validateInputs() {
        val emailValid = _uiState.value.email.contains("@")
        val passwordValid = _uiState.value.password.length >= 6
        _uiState.value = _uiState.value.copy(isButtonEnabled = emailValid && passwordValid && !_uiState.value.isLocked)
    }

    fun login() {
        if (_uiState.value.isLocked || _uiState.value.isOffline) return

        _uiState.value = _uiState.value.copy(isLoading = true, error = null)

        viewModelScope.launch {
            val result = authRepository.login(_uiState.value.email, _uiState.value.password)
            _uiState.value = _uiState.value.copy(isLoading = false)

            if (result) {
                _uiState.value = _uiState.value.copy(
                    navigateToMain = true,
                    failureCount = 0
                )
                if (_uiState.value.rememberMe) {
                    authRepository.saveToken("sample-token")
                }
            } else {
                val count = _uiState.value.failureCount + 1
                _uiState.value = _uiState.value.copy(
                    failureCount = count,
                    error = "Invalid credentials",
                    isLocked = count >= 3
                )
            }
        }
    }

    fun setOffline(isOffline: Boolean) {
        _uiState.value = _uiState.value.copy(isOffline = isOffline)
    }
}
