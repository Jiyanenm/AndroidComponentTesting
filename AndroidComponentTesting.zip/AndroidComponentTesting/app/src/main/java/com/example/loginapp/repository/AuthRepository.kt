package com.example.loginapp.repository

import kotlinx.coroutines.delay

class AuthRepository {

    private var token: String? = null

    suspend fun login(email: String, password: String): Boolean {
        // Simulate network delay
        delay(500)
        // Simple stub logic: accept password "password123"
        return password == "password123"
    }

    fun saveToken(token: String) {
        this.token = token
    }

    fun getToken(): String? = token
}
