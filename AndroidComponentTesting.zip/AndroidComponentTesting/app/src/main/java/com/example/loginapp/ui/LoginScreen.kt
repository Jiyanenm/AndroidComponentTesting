package com.example.loginapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.loginapp.viewmodel.LoginViewModel

@Composable
fun LoginScreen(viewModel: com.example.loginapp.viewmodel.LoginViewModel = viewModel()) {
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.padding(16.dp)) {
        OutlinedTextField(
            value = state.email,
            onValueChange = { viewModel.onEmailChange(it) },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = state.password,
            onValueChange = { viewModel.onPasswordChange(it) },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Checkbox(
                checked = state.rememberMe,
                onCheckedChange = { viewModel.onRememberMeChange(it) }
            )
            Text("Remember Me")
        }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { viewModel.login() },
            enabled = state.isButtonEnabled,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (state.isLoading) CircularProgressIndicator(modifier = Modifier.size(24.dp))
            else Text("Login")
        }
        Spacer(Modifier.height(8.dp))
        state.error?.let { Text(text = it, color = MaterialTheme.colorScheme.error) }
        if (state.isLocked) Text("Account locked after 3 failures", color = MaterialTheme.colorScheme.error)
        if (state.isOffline) Text("Offline: check your connection", color = MaterialTheme.colorScheme.onBackground)
    }
}
